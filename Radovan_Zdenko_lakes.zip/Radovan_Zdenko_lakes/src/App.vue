<template>
  <RouterView />
</template>

<script></script>
