# Vue alap | 2024.2.1

> Az alap tartalmaz minden olyan csomagot amely az órai feladatok elkészítéséhez szükséges.


## Node és a Vite kezelése

### Telepítés

Első indítás alkalmával:

```bash
npm install
```

### Fejlesztői szerver indítás

A fejlesztői szervet a következő paranccsal tudod elnidítani. Ezt követően a jelzett linken éred el a szervert.

```bash
npm run dev
```
